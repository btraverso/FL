﻿using UnityEngine;
using System.Collections;
using UnityEditor;

public class Attack : MonoBehaviour 
{
    GameObject player;
    GameObject pawnPiece;
    GameObject archerPiece;
    public GameObject enemy;
    EnemyClass pawn;
    EnemyClass archer;
    PlayerClass Kennedy;
 

	// Use this for initialization
	void Start () 
    {
        player = GameObject.FindGameObjectWithTag("Player");
        pawnPiece = GameObject.FindGameObjectWithTag("");
        archerPiece = GameObject.FindGameObjectWithTag("");
        pawn = enemy.GetComponent<EnemyClass>();
        Kennedy = player.GetComponent<KennedyClass>();
	}
	
     //Update is called once per frame
    void Update ()
    {
	
    }

    public void Attacktion()
    {
        Kennedy.isInCombat = true;
        EnemyClass temp = new EnemyClass();
        if (enemy = pawnPiece)
        {
            while (Kennedy.HP != 0)
            {
                Kennedy.isInCombat = true;
                Kennedy.HP -= temp.pawnDamage;
                var option = EditorUtility.DisplayDialogComplex("Attack?", "Do you want to attack back?", "Yes", "No", "Exit");
                switch (option)
                {
                    case 0:
                        Kennedy.isAttacking = true;
                        temp.pawnHP -= Kennedy.atkP;
                        break;
                    case 1:
                        Kennedy.HP -= temp.pawnDamage;
                        break;
                    case 2:
                        break;
                    default:
                        Debug.LogError("Unrecognized. Please try again");
                        break;
                }
                if (Kennedy.HP == 0)
                {
                   
                }
            }
            
        }



    }


}


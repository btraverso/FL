﻿using UnityEngine;
using System.Collections;
using System.Timers;

public class Timer : MonoBehaviour {
    public int p;

    public Timer(int p)
    {
        // TODO: Complete member initialization
        this.p = 3000;
    }

	// Use this for initialization
	public void Start () 
    {
        //Timer.Elapsed += timer_Elapsed; 
	}
	
	// Update is called once per frame
	public void Update () {
	
	}
    //public static void timer_Elapsed(object sender, ElapsedEventArgs e)
    //{
    //    PlayerClass pc = new PlayerClass();
    //    pc.HP++;
    //    if (pc.HP == pc.maxHP)
    //    {
    //        Timer.Destroy;
    //    }
    //}
}

﻿ using UnityEngine;
using System.Collections;

public class EnemyCollision : MonoBehaviour 
{
    public BoxCollider2D EnemeyArea;
    GameObject player;
    bool playerInEA;

    public GameObject enemy;
    EnemyClass pawn;
    EnemyClass archer;


	// Use this for initialization
	void Start () 
    {
        player = GameObject.FindGameObjectWithTag("Player");
        pawn = enemy.GetComponent<EnemyClass>();
        playerInEA = false;
	}
	
	// Update is called once per frame
	void Update () 
    {
      
	    if(playerInEA == true)
        {
            //pawn.Move();
            
        }
        if (playerInEA == false)
        {
            pawn.Rest();
        }
	}

    void OnTriggerEnter (Collider2D other)
    {
        if(other.gameObject == player)
        {
            playerInEA = true;
        }
    }

    void OnTriggerExit(Collider2D other)
    {
        if(other.gameObject == player)
        {
            playerInEA = false;
        }
    }
}
